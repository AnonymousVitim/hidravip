const help = (prefix) => {
	return `

━─━─────༺༻─────━─━
▣═─⊱【 𝐇𝐈𝐃𝐑𝐀 𝐁𝐎𝐓 】⊰─══
┊╭────── 
┊┠➤ ঔৣ͜͡𝑯͢𝑰𝑫͢𝑹𝜟 𝛩𝑭 ͢𝑯𝒀͢𝑷𝑬💸⃟ꦿ⸼ 
┊┠➤ wa.me/+5567996005372
┠╯
*┃⛨⧿✧ུNome : HIDRA BOT*
*┃⛨⧿✧ུVersão : V4.1(BETA)*
*┃⛨⧿✧ུStatus : ATIVO*
*┃⛨⧿✧ུAutor : HidraBotz*
*┃⛨⧿✧ུPrefixo : [ / ]*
╰───────────────╯
𝐆𝐑𝐔𝐏𝐎 𝐎𝐅𝐂 𝐃𝐎 𝐇𝐈𝐃𝐑𝐀:
https://chat.whatsapp.com/DPJzBotZSHxHZ0mRh1mNrP
━─━─────༺༻─────━─━
▣════─⊱【 𝐔𝐏𝐃𝐀𝐓𝐄 】⊰─════
║ *O que mudou?*
║|─⊱ Menu organizado
║|─⊱ Comandos sem prefixo (test)
║|─⊱ Comandos corrigidos
║|─⊱ Erros ortográficos corrigidos
║|─⊱ Comando porno atualizado
║|─⊱ Imagens novas ai no bot
║*Funções novas em teste*
║
▣═══─⊱【 𝐌𝐄𝐋𝐇𝐎𝐑𝐄𝐒 】⊰─═══
║
║|─⊱ *${prefix}sticker [faz figurinha]*
║|─⊱ *${prefix}play [nome da música]*
║|─⊱ *${prefix}toimg [figu vira foto]*
║|─⊱ *${prefix}wame [link do seu nmr]*
║|─⊱ *${prefix}meme [memes]*
║|─⊱ *${prefix}tts pt [seu texto]*
║|─⊱ *${prefix}ping [velocidade]*
║|─⊱ *${prefix}dono [info do hidra]*
║
▣═════─⊱【 𝐍𝐎𝐕𝐎𝐒 】⊰─═════
║
║|─⊱ *${prefix}animecry*
║|─⊱ *${prefix}chentai [premium]*
║|─⊱ *${prefix}gcpf [premium]*
║|─⊱ *${prefix}gay [@]*
║|─⊱ *${prefix}pack [premium]*
║|─⊱ *${prefix}gbin [premium]*
║|─⊱ *${prefix}destrava [premium]*
║|─⊱ *${prefix}gpessoa [premium]*
║|─⊱ *${prefix}spamcall*
║|─⊱ *${prefix}play (nome da msc)*
║
▣═══─⊱【 𝐏𝐀𝐑𝐀 𝐆𝐑𝐔𝐏𝐎𝐒 】⊰─═══
║
║|─⊱ *${prefix}closegc [fechar grupo]*
║|─⊱ *${prefix}opengc [abrir grupo]*
║|─⊱ *${prefix}antilink 1 [anti link]*
║|─⊱ *${prefix}antiracismo on*
║|─⊱ *${prefix}banir [banir membro]*
║|─⊱ *${prefix}admins [lista de adms*]*
║|─⊱ *${prefix}marcar [n usa toda hr]*
║|─⊱ *${prefix}linkgp [link do grupo]*
║|─⊱ *${prefix}promover [dar adm]*
║|─⊱ *${prefix}rebaixar [tirar adm]*
║|─⊱ *${prefix}bemvindo 1*
║|─⊱ *${prefix}grupoinfo [info]*
║|─⊱ *${prefix}setdesc [trocar desc]*
║|─⊱ *${prefix}setfoto [mudar foto]*
║|─⊱ *${prefix}porno [kkkk]*
║|─⊱ *${prefix}mia [fotos da mia]*
║
▣════─⊱【 𝐈𝐍𝐓𝐄𝐑𝐀𝐆𝐈𝐑 】⊰─════
║
║|─⊱ *${prefix}figu*
║|─⊱ *${prefix}toimg*
║|─⊱ *${prefix}memeindo*
║|─⊱ *${prefix}tts*
║|─⊱ *${prefix}lolih [on]*
║|─⊱ *${prefix}nsfwloli [off]*
║|─⊱ *${prefix}url2img*
║|─⊱ *${prefix}leens [na legenda]*
║|─⊱ *${prefix}wait [na legenda]*
║|─⊱ *${prefix}setprefix*
║
▣═════─⊱【 𝐎𝐔𝐓𝐑𝐎𝐒 】⊰─═════
║
║|─⊱ *${prefix}hidradmin*
║|─⊱ *${prefix}linkgp*
║|─⊱ *${prefix}simih [1/0]*
║|─⊱ *${prefix}marcar*
║|─⊱ *${prefix}add [@]*
║|─⊱ *${prefix}banir [@]*
║|─⊱ *${prefix}promover [@]*
║|─⊱ *${prefix}rebaixar*
║|─⊱ *${prefix}admins*
║|─⊱ *${prefix}marcar2*
║|─⊱ *${prefix}bc [texto]* (TM)
║|─⊱ *${prefix}marcar3*
║|─⊱ *${prefix}bloqueados*
║|─⊱ *${prefix}bloquear [@]*
║|─⊱ *${prefix}desbloquear [@]*
║|─⊱ *${prefix}limpar*
║|─⊱ *${prefix}bc [ *texto* ]*
║|─⊱ *${prefix}bemvindo [1/0]*
║|─⊱ *${prefix}clonar [@]*
║|─⊱ *${prefix}help1*
║|─⊱ *${prefix}dono*
║|─⊱ *${prefix}owner*
║|─⊱ *${prefix}tts [texto]*
║|─⊱ *${prefix}setnome*
║|─⊱ *${prefix}termux*
║|─⊱ *${prefix}setfoto*
║|─⊱ *${prefix}grupoinfo*
║|─⊱ *${prefix}ytmp4*
║|─⊱ *${prefix}bomdia*
║|─⊱ *${prefix}boanoite*
║|─⊱ *${prefix}marcar*
║|─⊱ *${prefix}marcar2*
║|─⊱ *${prefix}marcar3*
║|─⊱ *${prefix}calculadora*
║
▣════─⊱【 𝐈𝐌𝐀𝐆𝐄𝐍𝐒 】⊰─═════
║
║|─⊱ *${prefix}loli [off]*
║|─⊱ *${prefix}loli1*
║|─⊱ *${prefix}hentai*
║|─⊱ *${prefix}dono*
║|─⊱ *${prefix}porno*
║|─⊱ *${prefix}boanoite*
║|─⊱ *${prefix}bomdia*
║|─⊱ *${prefix}boatarde*
║|─⊱ *${prefix}mia [aleatórias]*
║|─⊱ *${prefix}rize [aleatórias]*
║|─⊱ *${prefix}minato [aleatórias]*
║|─⊱ *${prefix}boruto [aleatórias]*
║|─⊱ *${prefix}hinata [aleatórias]*
║|─⊱ *${prefix}sasuke [aleatórias]*
║|─⊱ *${prefix}sakura [aleatórias]*
║|─⊱ *${prefix}naruto [aleatórias]*
║|─⊱ *${prefix}meme*   
║|─⊱ *${prefix}lofi*
║|─⊱ *${prefix}malkova*
║|─⊱ *${prefix}canal*
║|─⊱ *${prefix}nsfwloli1*
║|─⊱ *${prefix}reislin*
║
▣══─⊱【 𝐏𝐔𝐗𝐀𝐑 𝐃𝐀𝐃𝐎𝐒 】⊰─════
║Talvez em breve!
║|─⊱ ip
║|─⊱ cnpj
║|─⊱ cpf
║|─⊱ geradorcpf
║|─⊱ cep
║|─⊱ placa
║
▣══─⊱【𝐈𝐍𝐓𝐄𝐋𝐈𝐆𝐄𝐍𝐂𝐈𝐀 𝐈𝐀】⊰─═══
║
║|─⊱ *${prefix}simih 1 (para ativar)*
║|─⊱ *${prefix}simih 0 (para desativar)*
║|─⊱ *${prefix}simi (sua mensagem)*
║
▣═════─⊱【𝐄𝐌 𝐓𝐄𝐒𝐓𝐄】⊰─═════
║ *Comandos sem prefixo*
║|─⊱ Canta ai bot
║|─⊱ Grita
║|─⊱ Sexo
║|─⊱ Bah
║
▣═════─⊱【𝐏𝐑𝐄𝐌𝐈𝐔𝐌】⊰─═════
║
║|─⊱ *${prefix}dado*
║|─⊱ *${prefix}cekvip*
║|─⊱ *${prefix}premiumlist*
║|─⊱ *${prefix}delete*
║|─⊱ *${prefix}modapk*
║|─⊱ *${prefix}indo10*
║|─⊱ *${prefix}qrcode*
║|─⊱ *${prefix}chentai*
║|─⊱ *${prefix}gcpf*
║|─⊱ *${prefix}gbin*
║|─⊱ *${prefix}pack*
║|─⊱ *${prefix}destrava*
║|─⊱ *${prefix}gpessoa*
║
▣═════─⊱【𝐆𝐑𝐔𝐏𝐎】⊰─═════
║
║|─⊱ *${prefix}banir*
║|─⊱ *${prefix}leveling [on/off]*
║|─⊱ *${prefix}level*
║|─⊱ *${prefix}add*
║|─⊱ *${prefix}promover*
║|─⊱ *${prefix}setfoto [na legenda]*
║|─⊱ *${prefix}setname [texto]*
║|─⊱ *${prefix}rebaixar*
║|─⊱ *${prefix}admins*
║|─⊱ *${prefix}marcar*
║|─⊱ *${prefix}marcar2*
║|─⊱ *${prefix}marcar3*
║|─⊱ *${prefix}bemvindo [1/0]*
║|─⊱ *${prefix}grupoinfo*
║|─⊱ *${prefix}bomdia*
║|─⊱ *${prefix}boatarde*
║|─⊱ *${prefix}boanoite*
║|─⊱ *${prefix}setdesc*
║|─⊱ *${prefix}bug [sua mensagem]*
║
▣══─⊱【𝐒𝐎 𝐏𝐑𝐎 𝐇𝐈𝐃𝐑𝐀】】⊰─══
║
║|─⊱ *${prefix}bug [sua mensagem]*
║|─⊱ *${prefix}clonar [@]*
║|─⊱ *${prefix}dono*
║|─⊱ *${prefix}ping [velocidade]*
║|─⊱ *${prefix}termux*
║|─⊱ *${prefix}gay [@]*
║|─⊱ *${prefix}wame*
║|─⊱ *${prefix}map (nome)*
║|─⊱ *${prefix}setppbot (marque img)*
║|─⊱ *${prefix}pinterest (nome)*
║|─⊱ *${prefix}desligar (so p o dono)*
║|─⊱ *${prefix}timer*
║
▣════─⊱【𝐎𝐔𝐓𝐑𝐎𝐒】⊰─═════
║
║|─⊱ *${prefix}neko*
║|─⊱ *${prefix}ttp [texto]*
║|─⊱ *${prefix}testime*
║|─⊱ *${prefix}tomp3*
║|─⊱ *${prefix}modoanime [on/off]*
║|─⊱ *${prefix}modonsfw [on/off]*
║|─⊱ *${prefix}happymod [jogo/app]*
║|─⊱ *${prefix}rize*
║|─⊱ *${prefix}ytsearch*
║|─⊱ *${prefix}moddroid [jogo/app]*
║|─⊱ *${prefix}xvideos [titulo]**
║|─⊱ *${prefix}nomegp
║|─⊱ *${prefix}animecry*
║|─⊱ *${prefix}gay1*
║|─⊱ *${prefix}next*
║|─⊱ *${prefix}alerta*
║|─⊱ *${prefix}belle [img aleatórias]*
║|─⊱ *${prefix}belle2
║|─⊱ *${prefix}belle3
║|─⊱ *${prefix}pronomeneu [texto]*
║|─⊱ *${prefix}hobby*
║
▣════─⊱【𝐌𝐔𝐒𝐈𝐂𝐀𝐒】⊰─═════
║|─⊱ *${prefix}camisafla*
║|─⊱ *${prefix}jogaroxo*
║|─⊱ *${prefix}narutinho*
║|─⊱ *${prefix}tobi*
║|─⊱ *${prefix}rapL*
║|─⊱ *${prefix}paypal*
║|─⊱ *${prefix}sad*
║|─⊱ *${prefix}beat1*
║|─⊱ *${prefix}beat2*
║
▣════─⊱【𝐎𝐔𝐓𝐑𝐎𝐒/2】⊰─════
║
║|─⊱ *${prefix}antilink [1/0]*
║|─⊱ *${prefix}brainly [pergunta]*
║|─⊱ *${prefix}antiracismo [on/off]*
║|─⊱ *${prefix}setnomebot*
║|─⊱ *${prefix}meme*

▣═══─⊱【𝐈𝐍𝐓𝐄𝐑𝐀𝐓𝐈𝐕𝐎】⊰─════
║NOTA »
║Manda a msg sem o prefixo
║|─⊱ fdp
║|─⊱ corno
║|─⊱ vsfd
║|─⊱ bot
║|─⊱ tmnc
║
║ *HIDRA NÉ BB?!*
▣═【ঔৣ͜͡𝑯͢𝑰𝑫͢𝑹𝜟 𝛩𝑭 ͢𝑯𝒀͢𝑷𝑬💸⃟ꦿ⸼ 】═▣`
}

exports.help = help













